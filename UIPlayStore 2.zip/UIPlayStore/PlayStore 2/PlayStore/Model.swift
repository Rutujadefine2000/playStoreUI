//
//  Model.swift
//  PlayStore
//
//  Created by Brahmastra on 26/12/22.
//  Copyright © 2022 Brahmastra. All rights reserved.
//

import Foundation
//struct MovieData:Codable
//{
//    let title:String
//    let popularity:String
//    let poster_path:String
//}
class moviesData:NSObject{
    let title:String?
    let popularity:String?
    let poster_path:String?
    
     init(title:String?, popularity:String?, poster_path:String) {
        self.title = title
        self.popularity = popularity
        self.poster_path = poster_path
    }
}







//https://image.tmdb.org/t/p/w200/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg



//
//
//class venues:NSObject{
//    let id1: String?
//    let name1:String?
//     
//    init(id1:String?,namme1:String){
//        self.id1 = id1
//        self.name1 = name1
//    }
//}
