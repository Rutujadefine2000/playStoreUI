//
//  GamesView.swift
//  PlayStore
//
//  Created by Brahmastra on 22/12/22.
//  Copyright © 2022 Brahmastra. All rights reserved.
//
//
//import UIKit
//
//class GamesView: UIViewController {
//
//  var MovieList = [MovieData]()
//    //var searchItems = [StoreData]()
//    //var searching = false
//    //var scopeButtonPressed = false
//    //let searchController = UISearchController(searchResultsController: nil)
//
//    @IBOutlet weak var myCollectionView: UICollectionView!
//    override func viewDidLoad() {
//        super.viewDidLoad()
//          // fillData()
//       // fillmyStoreData()
//
//               // configureSearchController()
//
//            }
////            private func configureSearchController()
////            {
////                searchController.loadViewIfNeeded()
////               // searchController.searchResultsUpdater = self
////              //  searchController.searchBar.delegate = self
////                searchController.obscuresBackgroundDuringPresentation = false
////                searchController.searchBar.enablesReturnKeyAutomatically = false
////                searchController.searchBar.returnKeyType = UIReturnKeyType.done
////                searchController.searchBar.scopeButtonTitles = ["For you","Top Charts","Childen","Events","Premium","Categories"]
////                definesPresentationContext = true
////                searchController.searchBar.placeholder = "Search for Apps and games"
////                self.navigationItem.searchController = searchController
////                self.navigationItem.hidesSearchBarWhenScrolling = false
////                }
//    func fetchData()
//    {
//        let url = URL(string: "https://api.themoviedb.org/3/movie/popular?api_key=60af9fe8e3245c53ad9c4c0af82d56d6&language=en-US&page=1")
//        let task = URLSession.shared.dataTask(with: url!, completionHandler: {
//            (data, response, error) in
//            guard let data = data, error == nil else
//            {
//                print("Error occured while Accessing Data")
//                return
//            }
//            do{
//                self.MovieList = try JSONDecoder().decode([MovieData].self, from: data)
//            }
//            catch
//            {
//                print("error While Decoding \(error)")
//            }
//            DispatchQueue.main.async {
//                self.myCollectionView.reloadData()
//            }
//        })
//        task.resume()
//    }
//}
//extension UIImageView
//{
//    func downloadImage(from url:URL)
//    {
//        contentMode = .scaleToFill
//        let dataTask = URLSession.shared.dataTask(with: url, completionHandler: {
//            (data, response, error) in
//            guard let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
//                let mimtype = response?.mimeType, mimtype.hasPrefix("poster_path"),
//                let data = data, error == nil,
//            let image = UIImage(data: data)
//            else
//            {
//                print("error occured \(error)")
//                return
//            }
//            DispatchQueue.main.async {
//                self.image = image
//            }
//
//        })
//        dataTask.resume()
//    }
//}
//extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource ,UICollectionViewDelegateFlowLayout
//{
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//
//    }
//
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell =
//    }
//
//
//}
