//
//  BooksView.swift
//  PlayStore
//
//  Created by Brahmastra on 22/12/22.
//  Copyright © 2022 Brahmastra. All rights reserved.
//

import UIKit

class BooksView: UIViewController {
    var myProductList = [StoreData]()
       var searchItems = [StoreData]()
       var searching = false
       var scopeButtonPressed = false
       let searchController = UISearchController(searchResultsController: nil)

    @IBOutlet weak var myCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()


      fillmyStoreData()
   
        configureSearchController()
       
    }
    private func configureSearchController()
    {
        searchController.loadViewIfNeeded()
        searchController.searchResultsUpdater = self
        searchController.searchBar.delegate = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.enablesReturnKeyAutomatically = false
        searchController.searchBar.returnKeyType = UIReturnKeyType.done
        searchController.searchBar.scopeButtonTitles = ["For you","Top Charts","Childen","Events","Premium","Categories"]
        definesPresentationContext = true
        searchController.searchBar.placeholder = "Search for Apps and games"
        self.navigationItem.searchController = searchController
        self.navigationItem.hidesSearchBarWhenScrolling = false
        
        
        
    }
    public func fillmyStoreData()
    {
        myProductList.removeAll()
        for product in productList
        {
            if(product.category=="movie")
            {
                myProductList.append(product)
            }
        }
    }
}
extension BooksView: UICollectionViewDelegate,UICollectionViewDataSource, UISearchResultsUpdating,
UISearchBarDelegate, UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if searching || scopeButtonPressed
        {
            return searchItems.count
        }
        else{
            return myProductList.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = myCollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! BooksCollectionViewCell
        if searching || scopeButtonPressed {
            cell.myImageView.image = UIImage(named: searchItems[indexPath.row].ProductImage)
            cell.myLabel.text = searchItems[indexPath.row].ProductName
        }
        else{
            cell.myImageView.image = UIImage(named: myProductList[indexPath.row].ProductImage)
                       cell.myLabel.text = myProductList[indexPath.row].ProductName
        }
      cell.layer.borderColor = UIColor.gray.cgColor
        cell.layer.borderWidth = 2
        return cell
        
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        let scopeButton = searchController.searchBar.scopeButtonTitles![searchController.searchBar.selectedScopeButtonIndex]
        let searchText = searchController.searchBar.text!
        if !searchText.isEmpty
        {
            searching = true
            searchItems.removeAll()
            for product in myProductList
            {
                if product.ProductName.lowercased().contains(searchText.lowercased()) && (product.ProductType==scopeButton||scopeButton=="All")
                {
                    searchItems.append(product)
                }
            }
        }
        else{
            if scopeButtonPressed
            {
                searchItems.removeAll()
                let scopeButton =
                searchController.searchBar.scopeButtonTitles!
                [searchController.searchBar.selectedScopeButtonIndex]
                for product in myProductList
                {
//                 //   if(product.ProductTypescopeButton||scopeButton=="All")
//                    {
//                        searchItems.append(product)
//                    }
                }
                searching = false
                myCollectionView.reloadData()
                
            }
            else{
                searching = false
                searchItems.removeAll()
                searchItems = myProductList
                
            }
        }
        myCollectionView.reloadData()
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searching = false
        searchItems.removeAll()
        myCollectionView.reloadData()
    }
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        
        searchController.searchBar.text = ""
        scopeButtonPressed = true
        let scopeButton =
            searchController.searchBar.scopeButtonTitles!
        [searchController.searchBar.selectedScopeButtonIndex]
        searchItems.removeAll()
        for product in myProductList
        {
         //   if(product.ProductType==scopeButton||scopeButton=="All"){
//            {
//                //
//            }
            }
        myCollectionView.reloadData()
        }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = (collectionView.frame.size.width-10)/2
          return CGSize(width: size, height: 300)
    }

    }
    


