//
//  CollectionViewCell.swift
//  UIPlayStore
//
//  Created by Brahmastra on 22/12/22.
//  Copyright © 2022 Brahmastra. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var images: UIImageView!
}
