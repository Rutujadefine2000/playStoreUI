//
//  Data.swift
//  UIPlayStore
//
//  Created by Brahmastra on 22/12/22.
//  Copyright © 2022 Brahmastra. All rights reserved.
//

import Foundation
struct PlayStoreData {
    let sectionType:String
    let Movies:[String]
}
