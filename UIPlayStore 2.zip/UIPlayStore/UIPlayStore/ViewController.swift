//
//  ViewController.swift
//  UIPlayStore
//
//  Created by Brahmastra on 22/12/22.
//  Copyright © 2022 Brahmastra. All rights reserved.
//

import UIKit

var data = [PlayStoreData(sectionType: "Movies", Movies: ["movie1","movie2","movie3","movie4","movie5","movie6","movie7","movie8","movie9","movie10"]),
            PlayStoreData(sectionType: "Games", Movies: ["game1", "game2", "game3", "game4", "game5", "game6", "game7", "game8", "game9", "game10"]),
            PlayStoreData(sectionType: "webSeries", Movies: ["web1","web2","web3","web4","web5","web6","web7","web8","web9","web10",])]

class ViewController: UIViewController {
    let searchController = UISearchController(searchResultsController: nil)

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

extension ViewController: UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as!
        TableViewCell
        cell.collectionView.tag = indexPath.section
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        return data[section].sectionType
    
}
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        view.tintColor = .brown
    }
//    private func configureSearchController(){
//        searchController.searchResultsUpdater = self as! UISearchResultsUpdating
//        searchController.searchBar.delegate = self as! UISearchBarDelegate
//        searchController.obscuresBackgroundDuringPresentation = false
//        searchController.searchBar.enablesReturnKeyAutomatically = false
//        searchController.searchBar.returnKeyType = UIReturnKeyType.done
//        self.navigationItem.searchController = searchController
//        self.navigationItem.hidesSearchBarWhenScrolling = false
//        definesPresentationContext = true
//        searchController.searchBar.placeholder = "Search for apps & games"
//
//    }
//}
//
//extension ViewController: UITableViewController, UISearchResultsUpdating {
//    func updateSearchResults(for searchController: UISearchController) {
//        <#code#>
//    }
//
//
//    var filteredTableData = [String]()
//}
}
