//
//  GameViewController.swift
//  PlayStore
//
//  Created by Brahmastra on 26/12/22.
//  Copyright © 2022 Brahmastra. All rights reserved.
//

import UIKit

class GameViewController: UIViewController {
    
//  var MovieList = [moviesData]()
    
    @IBOutlet weak var myCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
fetchData()
       
    }
    func fetchData()
    {
        
          
        }

}

//
//do{
//              let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)as! NSDictionary
//              let belowDict = json["response"] as! NSDictionary
//              let data = belowDict["venues"] as! NSArray
//              for i in 0 ..< data.count{
//                  if let basicArray = data[i] as? NSDictionary{
//                      let venueid = basicArray["id"]as! String
//                      let venuename = basicArray["name"]as! String
//                      self.venue.append(venues(id1: venueid, name1: venuename, isSelectetd: false))
//                      DispatchQueue.main.async {
//                          self.myTableView.reloadData()
//                      }
//

//
//do{
//    let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as!
//    let belowArr = json["results"] as! NSArray
//    let data = json["genre_ids"] as! NSArray
//    for i in 0..< data.count{
//
//    }
//}


//
//
//extension UIImageView
//{
//    func downloadImage(from url:URL)
//    {
//        contentMode = .scaleToFill
//        let dataTask = URLSession.shared.dataTask(with: url, completionHandler: {
//            (data, response, error) in
//            guard let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
//                let mimtype = response?.mimeType, mimtype.hasPrefix("poster_path"),
//                let data = data, error == nil,
//            let image = UIImage(data: data)
//            else
//            {
//                print("error occured \(error)")
//                return
//            }
//            DispatchQueue.main.async {
//                self.image = image
//            }
//
//        })
//        dataTask.resume()
//    }
//}
//extension GameViewController: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return MovieList.count
//    }
//    
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = myCollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! GamesCollectionViewCell
//   
//        let urlImage = URL(string: MovieList[indexPath.row].poster_path ?? )
//        cell.myImageView.downloadImage(from: urlImage!)
//        cell.myImageView.layer.cornerRadius = 25
//        cell.myLabel1.text = MovieList[indexPath.row].title
//        cell.myLabel2.text = MovieList[indexPath.row].popularity
//        cell.layer.borderColor = UIColor.black.cgColor
//        cell.layer.borderWidth = 1
//          return cell
//    }
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        let size = (collectionView.frame.size.width-10)/2
//        return CGSize(width: size, height: size)
//    }
//    }
//    
