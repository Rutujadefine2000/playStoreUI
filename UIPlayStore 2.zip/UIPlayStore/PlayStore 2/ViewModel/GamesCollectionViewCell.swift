//
//  GamesCollectionViewCell.swift
//  PlayStore
//
//  Created by Brahmastra on 22/12/22.
//  Copyright © 2022 Brahmastra. All rights reserved.
//

import UIKit

class GamesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myImageView: UIImageView!
    
    @IBOutlet weak var myLabel1: UILabel!
     @IBOutlet weak var myLabel2: UILabel!
    override func prepareForReuse() {
        self.myImageView.image = nil
    }
}
