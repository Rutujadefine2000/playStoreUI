//
//  StoreData.swift
//  PlayStore
//
//  Created by Brahmastra on 23/12/22.
//  Copyright © 2022 Brahmastra. All rights reserved.
//

import Foundation
var productList = [StoreData]()
class StoreData {
    var ProductName: String
    var ProductType: String
    var ProductImage: String
    var category: String
    init(pName:String,pType:String,pImage:String,pCategory:String) {
        ProductName = pName
        ProductType = pType
        ProductImage = pImage
        category = pCategory
    }
    
}
public func fillData()
{
    let product1 = StoreData(pName: "HolleyWood movie", pType: "HolleyWood", pImage: "Movie HollyWood", pCategory: "movie")
    productList.append(product1)
    
    let product2 = StoreData(pName: "Bollywood HollyWood movie", pType: "Bollywood HollyWood", pImage: "Bollywood HollyWood movie", pCategory: "movie")
       productList.append(product2)
    let product3 = StoreData(pName: "Drishyam2 movie", pType: "Bollywood", pImage: "Drishyam2 movie", pCategory: "movie")
       productList.append(product3)
    let product4 = StoreData(pName: "Herry Poter movie", pType: "HolleyWood", pImage: "Herry Poter movie", pCategory: "movie")
       productList.append(product4)
    let product5 = StoreData(pName: "Chota Bhim movie", pType: "ChildMovie", pImage: "Chota Bhim movie", pCategory: "movie")
       productList.append(product5)
    let product6 = StoreData(pName: "Hollywood movie part-1", pType: "HolleyWood", pImage: "Hollywood movie part-1", pCategory: "movie")
       productList.append(product6)
    let product7 = StoreData(pName: "HolleyWood WAkAND Movie", pType: "HolleyWood", pImage: "HolleyWood WAkAND Movie", pCategory: "movie")
       productList.append(product7)
    let product8 = StoreData(pName: " HollyWood Movie BlackADAM part-1", pType: "HolleyWood", pImage: " HollyWood Movie BlackADAM part-1", pCategory: "movie")
       productList.append(product8)
    let product9 = StoreData(pName: "Kantara movie", pType: "BollyWood", pImage: "Kantara movie", pCategory: "movie")
       productList.append(product9)
    let product10 = StoreData(pName: "sitaRamam movie", pType: "BolleyWood", pImage: "sitaRamam movie", pCategory: "movie")
    productList.append(product10)
    
    let product11 = StoreData(pName: "CandyCrush Hard Game", pType: "Hard Games", pImage: "CandyCrush Hard Game", pCategory: "Game")
      productList.append(product11)
    let product12 = StoreData(pName: "Carrem Simple Game", pType: "Simple Games", pImage: "Carrem Simple Game", pCategory: "Game")
      productList.append(product12)
    let product13 = StoreData(pName: "Color Girls Game", pType: " Girls Games", pImage: "Color Girls Game", pCategory: "Game")
      productList.append(product13)
    let product14 = StoreData(pName: "FreeFire Boyes Game", pType: "Boyes Games", pImage: "FreeFire Boyes Game", pCategory: "Game")
      productList.append(product14)
    let product15 = StoreData(pName: "FruitsCuttor Child Game", pType: "Childs Games", pImage: "FruitsCuttor Child Game", pCategory: "Game")
      productList.append(product15)
    let product16 = StoreData(pName: "LoGoQuiz Hard Game", pType: "Hard Games", pImage: "LoGoQuiz Hard Game", pCategory: "Game")
      productList.append(product16)
    let product17 = StoreData(pName: "Ludo Simple Game", pType: "Simple Games", pImage: "Ludo Simple Game", pCategory: "Game")
      productList.append(product17)
    let product18 = StoreData(pName: "Puzzle Hard Game", pType: "Hard Games", pImage: "Puzzle Hard Game", pCategory: "Game")
      productList.append(product18)
    let product19 = StoreData(pName: "RC20 Game", pType: "Boyes Games", pImage: "RC20 Game", pCategory: "Game")
      productList.append(product19)
    let product20 = StoreData(pName: "word Puzzle Game", pType: "Childs Games", pImage: "word Puzzle Game", pCategory: "Game")
        productList.append(product20)
    
   
    let product21 = StoreData(pName: "faceBook", pType: "web App", pImage: "word Puzzle Game", pCategory: "Apps")
              productList.append(product21)
    let product22 = StoreData(pName: "instagram", pType: "web App", pImage: "instagram", pCategory: "Apps")
              productList.append(product22)
    let product23 = StoreData(pName: "moj", pType: "Native Games", pImage: "moj", pCategory: "Apps")
              productList.append(product23)
    let product24 = StoreData(pName: "PhonePe", pType: "web App", pImage: "PhonePe", pCategory: "Apps")
              productList.append(product24)
    let product25 = StoreData(pName: "resso", pType: "Native Games", pImage: "resso", pCategory: "Apps")
              productList.append(product25)
    let product26 = StoreData(pName: "ShareChat", pType: "Native App", pImage: "ShareChat", pCategory: "Apps")
              productList.append(product26)
    let product27 = StoreData(pName: "SnapChat", pType: "Native App", pImage: "SnapChat", pCategory: "Apps")
              productList.append(product27)
    let product28 = StoreData(pName: "spotify", pType: "Songs App", pImage: "spotify", pCategory: "Apps")
              productList.append(product28)
    let product29 = StoreData(pName: "WhatsApp", pType: "Navtive App", pImage: "WhatsApp", pCategory: "Apps")
              productList.append(product29)
    let product30 = StoreData(pName: "Zee5", pType: "Native App", pImage: "Zee5", pCategory: "Apps")
              productList.append(product30)
    
    let product31 = StoreData(pName: "Art", pType: "Classics", pImage: "Art", pCategory: "Books")
                 productList.append(product31)
    let product32 = StoreData(pName: "God", pType: "God Stoories", pImage: "God", pCategory: "Books")
                 productList.append(product32)
    let product33 = StoreData(pName: "Habits", pType: "Classics", pImage: "Habits", pCategory: "Books")
                 productList.append(product33)
    let product34 = StoreData(pName: "MindSet1", pType: "MindSetBooks", pImage: "MindSet1", pCategory: "Books")
                 productList.append(product34)
    let product35 = StoreData(pName: "MindSet2", pType: "MindSetBooks", pImage: "MindSet2", pCategory: "Books")
                 productList.append(product35)
    let product36 = StoreData(pName: "MindSet3", pType: "MindSetBooks", pImage: "MindSet3", pCategory: "Books")
                 productList.append(product36)
    let product37 = StoreData(pName: "Thoughts", pType: "ThoughtsBooks", pImage: "Thoughts", pCategory: "Books")
                 productList.append(product37)
    let product38 = StoreData(pName: "Thoughts2", pType: "ThoughtsBooks", pImage: "Thoughts2", pCategory: "Books")
                 productList.append(product38)
    let product39 = StoreData(pName: "Works", pType: "Classics", pImage: "Works", pCategory: "Books")
                 productList.append(product39)
    let product40 = StoreData(pName: "Yoga", pType: "Classics", pImage: "Yoga", pCategory: "Books")
                 productList.append(product40)
}
