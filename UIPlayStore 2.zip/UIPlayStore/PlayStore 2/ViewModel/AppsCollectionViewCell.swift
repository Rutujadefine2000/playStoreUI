//
//  AppsCollectionViewCell.swift
//  PlayStore
//
//  Created by Brahmastra on 22/12/22.
//  Copyright © 2022 Brahmastra. All rights reserved.
//

import UIKit

class AppsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myImageView: UIImageView!
    
    
    @IBOutlet weak var myLabel: UILabel!
}
